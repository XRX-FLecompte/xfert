[CmdletBinding()]
param(
    [string]$WorkspaceRoot = "C:\Xerox\FFCoreForChatGPT",
    [int]$EventLogDays = 7
)

$ErrorActionPreference = "Continue"
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$diagRoot = Join-Path $WorkspaceRoot "files\diagnostics\FFCore_Diagnostics_$timestamp"
New-Item -ItemType Directory -Force -Path $diagRoot | Out-Null

function Write-Section {
    param([string]$Name, [scriptblock]$Command)
    $path = Join-Path $diagRoot $Name
    try {
        & $Command | Out-File -FilePath $path -Encoding UTF8 -Width 240
    }
    catch {
        "ERROR: $($_.Exception.Message)" | Out-File -FilePath $path -Encoding UTF8
    }
}

$ffInstall = "C:\Program Files\Xerox\FreeFlow Core"
$ffRuntime = "C:\Xerox\FreeFlow\Core"
$installLogs = Join-Path $ffInstall "Logs\Install"

Write-Section "00_CollectionSummary.txt" {
    [pscustomobject]@{
        ComputerName = $env:COMPUTERNAME
        UserName = $env:USERNAME
        Timestamp = (Get-Date)
        WorkspaceRoot = $WorkspaceRoot
        FFCoreInstallPathExists = (Test-Path -LiteralPath $ffInstall)
        FFCoreRuntimePathExists = (Test-Path -LiteralPath $ffRuntime)
        FFCoreInstallLogsExist = (Test-Path -LiteralPath $installLogs)
    }
}

Write-Section "01_OS_ComputerInfo.txt" {
    Get-ComputerInfo | Select-Object CsName, WindowsProductName, WindowsVersion, OsHardwareAbstractionLayer, OsArchitecture, OsBuildNumber, OsInstallDate, CsTotalPhysicalMemory
}

Write-Section "02_Disks.txt" {
    Get-Volume | Sort-Object DriveLetter | Select-Object DriveLetter, FileSystemLabel, FileSystem, DriveType, HealthStatus, SizeRemaining, Size
}

Write-Section "03_Xerox_Services.txt" {
    Get-Service | Where-Object { $_.Name -like "*Xerox*" -or $_.DisplayName -like "*Xerox*" -or $_.Name -like "*FreeFlow*" -or $_.DisplayName -like "*FreeFlow*" } |
        Sort-Object DisplayName |
        Select-Object Status, Name, DisplayName, StartType
}

Write-Section "04_Xerox_Processes.txt" {
    Get-Process | Where-Object { $_.Company -like "*Xerox*" -or $_.ProcessName -like "*FreeFlow*" -or $_.ProcessName -like "*Xerox*" } |
        Sort-Object ProcessName |
        Select-Object ProcessName, Id, CPU, WorkingSet64, Path
}

Write-Section "05_FFCore_Install_Folder_Listing.txt" {
    if (Test-Path -LiteralPath $ffInstall) {
        Get-ChildItem -LiteralPath $ffInstall -Force | Select-Object Mode, Length, LastWriteTime, Name
    }
    else {
        "Path not found: $ffInstall"
    }
}

Write-Section "06_FFCore_Runtime_Folder_Listing.txt" {
    if (Test-Path -LiteralPath $ffRuntime) {
        Get-ChildItem -LiteralPath $ffRuntime -Force | Select-Object Mode, Length, LastWriteTime, Name
    }
    else {
        "Path not found: $ffRuntime"
    }
}

Write-Section "07_Recent_Application_Errors.txt" {
    $start = (Get-Date).AddDays(-1 * [Math]::Abs($EventLogDays))
    Get-WinEvent -FilterHashtable @{ LogName = "Application"; StartTime = $start; Level = 1,2,3 } -ErrorAction SilentlyContinue |
        Where-Object { $_.ProviderName -like "*Xerox*" -or $_.Message -like "*Xerox*" -or $_.Message -like "*FreeFlow*" -or $_.Message -like "*SQL*" } |
        Select-Object TimeCreated, ProviderName, Id, LevelDisplayName, Message
}

Write-Section "08_Recent_System_Errors.txt" {
    $start = (Get-Date).AddDays(-1 * [Math]::Abs($EventLogDays))
    Get-WinEvent -FilterHashtable @{ LogName = "System"; StartTime = $start; Level = 1,2,3 } -ErrorAction SilentlyContinue |
        Where-Object { $_.ProviderName -like "*Service Control Manager*" -or $_.Message -like "*Xerox*" -or $_.Message -like "*FreeFlow*" -or $_.Message -like "*SQL*" } |
        Select-Object TimeCreated, ProviderName, Id, LevelDisplayName, Message
}

if (Test-Path -LiteralPath $installLogs) {
    $dest = Join-Path $diagRoot "InstallLogs"
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    Get-ChildItem -LiteralPath $installLogs -File -Recurse -Include "*.log","*.txt" -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 100 |
        ForEach-Object {
            $safeName = ($_.FullName.Substring($installLogs.Length).TrimStart("\") -replace "[\\/:*?""<>|]", "_")
            Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $dest $safeName) -Force
        }
}

$configDest = Join-Path $diagRoot "ConfigCopies"
New-Item -ItemType Directory -Force -Path $configDest | Out-Null
foreach ($basePath in @($ffInstall, $ffRuntime)) {
    if (Test-Path -LiteralPath $basePath) {
        Get-ChildItem -LiteralPath $basePath -Recurse -File -Include "*.config","*.json","*.xml","*.ini","*.txt" -ErrorAction SilentlyContinue |
            Where-Object { $_.Length -lt 5MB } |
            Select-Object -First 200 |
            ForEach-Object {
                $prefix = if ($basePath -eq $ffInstall) { "Install" } else { "Runtime" }
                $safeName = "$prefix`_" + ($_.FullName.Substring($basePath.Length).TrimStart("\") -replace "[\\/:*?""<>|]", "_")
                Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $configDest $safeName) -Force
            }
    }
}

Write-Host "Diagnostics collected at $diagRoot"
