[CmdletBinding()]
param(
    [string]$WorkspaceRoot = "C:\Xerox\FFCoreForChatGPT"
)

$ErrorActionPreference = "Stop"

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$outputRoot = Join-Path $WorkspaceRoot "output"
$bundlePath = Join-Path $outputRoot "FFCore_Troubleshooting_Bundle_$timestamp.zip"
$include = @()

New-Item -ItemType Directory -Force -Path $outputRoot | Out-Null

foreach ($path in @(
    (Join-Path $WorkspaceRoot "AGENTS.md"),
    (Join-Path $WorkspaceRoot "files"),
    (Join-Path $WorkspaceRoot "prompts")
)) {
    if (Test-Path -LiteralPath $path) {
        $include += $path
    }
}

if ($include.Count -eq 0) {
    throw "No files found to package under $WorkspaceRoot"
}

Compress-Archive -LiteralPath $include -DestinationPath $bundlePath -Force
Write-Host "Created $bundlePath"
