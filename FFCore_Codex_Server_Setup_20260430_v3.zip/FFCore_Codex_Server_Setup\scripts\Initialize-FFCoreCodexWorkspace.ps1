[CmdletBinding()]
param(
    [string]$WorkspaceRoot = "C:\Xerox\FFCoreForChatGPT",
    [switch]$OverwriteExistingPrompts
)

$ErrorActionPreference = "Stop"

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$kitRoot = Split-Path -Parent $scriptDir

$folders = @(
    $WorkspaceRoot,
    (Join-Path $WorkspaceRoot "documentation"),
    (Join-Path $WorkspaceRoot "files"),
    (Join-Path $WorkspaceRoot "files\scripts"),
    (Join-Path $WorkspaceRoot "files\diagnostics"),
    (Join-Path $WorkspaceRoot "output"),
    (Join-Path $WorkspaceRoot "prompts"),
    (Join-Path $WorkspaceRoot "temp")
)

foreach ($folder in $folders) {
    New-Item -ItemType Directory -Force -Path $folder | Out-Null
}

Copy-Item -LiteralPath (Join-Path $kitRoot "AGENTS.md") -Destination (Join-Path $WorkspaceRoot "AGENTS.md") -Force
Copy-Item -LiteralPath (Join-Path $kitRoot "FFCore-Support.code-workspace") -Destination (Join-Path $WorkspaceRoot "FFCore-Support.code-workspace") -Force

$sourceDocs = Join-Path $kitRoot "documentation"
if (Test-Path -LiteralPath $sourceDocs) {
    Copy-Item -Path (Join-Path $sourceDocs "*") -Destination (Join-Path $WorkspaceRoot "documentation") -Force -Recurse
}

$sourceScripts = Join-Path $kitRoot "scripts"
Copy-Item -LiteralPath (Join-Path $sourceScripts "Collect-FFCoreDiagnostics.ps1") -Destination (Join-Path $WorkspaceRoot "files\scripts\Collect-FFCoreDiagnostics.ps1") -Force
Copy-Item -LiteralPath (Join-Path $sourceScripts "Package-FFCoreTroubleshootingBundle.ps1") -Destination (Join-Path $WorkspaceRoot "files\scripts\Package-FFCoreTroubleshootingBundle.ps1") -Force

$sourcePrompts = Join-Path $kitRoot "prompts"
if (Test-Path -LiteralPath $sourcePrompts) {
    Get-ChildItem -LiteralPath $sourcePrompts -File | ForEach-Object {
        $dest = Join-Path (Join-Path $WorkspaceRoot "prompts") $_.Name
        if ($OverwriteExistingPrompts -or -not (Test-Path -LiteralPath $dest)) {
            Copy-Item -LiteralPath $_.FullName -Destination $dest -Force
        }
    }
}

Write-Host "FFCore Codex workspace prepared at $WorkspaceRoot"
Write-Host "Open Codex against this folder and follow AGENTS.md."
