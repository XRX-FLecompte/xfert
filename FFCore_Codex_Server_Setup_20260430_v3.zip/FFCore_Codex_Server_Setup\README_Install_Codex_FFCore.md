# FFCore Codex Support Kit

Use this kit to prepare another FreeFlow Core server for Codex-assisted troubleshooting.

## What This Kit Contains
- `AGENTS.md`: operating rules for Codex in the FFCore support workspace.
- `FFCore-Support.code-workspace`: VS Code/Codex workspace file.
- `scripts\Initialize-FFCoreCodexWorkspace.ps1`: creates the support workspace and copies this kit into place.
- `scripts\Collect-FFCoreDiagnostics.ps1`: read-only FFCore/server diagnostic collection.
- `scripts\Package-FFCoreTroubleshootingBundle.ps1`: packages collected files for sharing.
- `documentation\`: local Xerox references copied from the source support workspace.
- `prompts\`: reusable FFCore troubleshooting prompt references.

## Install Codex on the Other Server
Install the Codex application or CLI using your approved OpenAI/company distribution method, then sign in with the account authorized to use Codex.

This kit does not include a Codex installer. It prepares the server-side troubleshooting workspace that Codex should open after installation.

## Prepare the Workspace
1. Copy the full `FFCore_Codex_Server_Setup` folder to the other server.
2. Open PowerShell as Administrator if you want to place the workspace under `C:\Xerox`.
3. From the copied kit folder, run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\scripts\Initialize-FFCoreCodexWorkspace.ps1
```

4. Open Codex against:

```text
C:\Xerox\FFCoreForChatGPT
```

5. Start with this prompt:

```text
Use the local AGENTS.md instructions. First inspect C:\Xerox\FFCoreForChatGPT\prompts and C:\Xerox\FFCoreForChatGPT\documentation. Help me troubleshoot the FFCore issue using read-only inspection first.
```

## Collect Diagnostics
Run this from the prepared workspace:

```powershell
C:\Xerox\FFCoreForChatGPT\files\scripts\Collect-FFCoreDiagnostics.ps1
```

The script writes a timestamped folder under:

```text
C:\Xerox\FFCoreForChatGPT\files\diagnostics
```

It collects service status, install/runtime folder listings, selected event log entries, FFCore install logs, and safe config copies. It does not restart services or modify FFCore.

## Package Diagnostics
After collecting diagnostics, run:

```powershell
C:\Xerox\FFCoreForChatGPT\files\scripts\Package-FFCoreTroubleshootingBundle.ps1
```

The zip is written to:

```text
C:\Xerox\FFCoreForChatGPT\output
```

## Local Documentation Priority
Use these first when troubleshooting:
1. `C:\Xerox\FFCoreForChatGPT\documentation\Xerox_FreeFlow_Core_Help_en-US.pdf`
2. `C:\Xerox\FFCoreForChatGPT\documentation\FreeFlow_core_installation_guide_en-US.pdf`
3. `C:\Xerox\FFCoreForChatGPT\documentation\Xerox_FreeFlow_Core_8.1.0_Release_Notes_en-US.pdf`
4. `C:\Xerox\FFCoreForChatGPT\documentation\Security-Guide-Information-Assurance-Disclosure-Xerox-FreeFlow-Core-8.0.pdf`

## Safety Notes
- Do not restart FFCore services unless explicitly approved.
- Do not run FFCore installers unless explicitly approved.
- Do not modify `*.exe` or `*.dll` files.
- Treat `C:\Xerox\FreeFlow\Core` runtime data as read-only unless the change is explicitly required and approved.
