# FFCore Support Workspace Agent Instructions

## Scope
- Primary workspace: `C:\Xerox\FFCoreForChatGPT`
- Support folders in this workspace:
  - `documentation\` for Xerox PDF docs and exported web references
  - `files\` for logs, scripts, config copies, and diagnostic bundles to analyze
  - `prompts\` for reusable Codex/ChatGPT prompt references
  - `output\` for generated reports, scripts, and exports
  - `temp\` for temporary working files
- Product install/runtime paths may be referenced when needed:
  - `C:\Program Files\Xerox\FreeFlow Core`
  - `C:\Xerox\FreeFlow\Core`

## Output Policy
- Write every generated file to `C:\Xerox\FFCoreForChatGPT\output` unless explicitly told otherwise.

## Prompt Reuse Policy
- Before answering a question, building a script, or creating instructions, check `C:\Xerox\FFCoreForChatGPT\prompts` for reusable content first.
- Reuse and adapt existing prompt/reference files when relevant instead of recreating from scratch.
- Save each new reusable chat outcome as a reference file in `C:\Xerox\FFCoreForChatGPT\prompts`.
- Use clear filenames in the format: `Topic_Chat_Reference.txt`.

## Primary References
- Use local documentation in `C:\Xerox\FFCoreForChatGPT\documentation` first.
- Priority order:
  1. `C:\Xerox\FFCoreForChatGPT\documentation\Xerox_FreeFlow_Core_Help_en-US.pdf`
  2. `C:\Xerox\FFCoreForChatGPT\documentation\FreeFlow_core_installation_guide_en-US.pdf`
  3. `C:\Xerox\FFCoreForChatGPT\documentation\Xerox_FreeFlow_Core_8.1.0_Release_Notes_en-US.pdf`
  4. `C:\Xerox\FFCoreForChatGPT\documentation\Security-Guide-Information-Assurance-Disclosure-Xerox-FreeFlow-Core-8.0.pdf`
  5. `C:\Xerox\FFCoreForChatGPT\output\CustomerOverride_List.json` and `.csv`, when present
- If documentation and observed system state conflict, report both before risky changes.

## Working Rules
- Prefer read-only inspection first: `Get-ChildItem`, `Get-Content`, `Select-String`, config review, and log review.
- Explain intended impact before changing config, scripts, services, or executables.
- Do not restart or stop services, execute installers, submit jobs, or run product EXEs unless explicitly requested.
- Do not modify binaries such as `*.exe` or `*.dll` in place.
- For config/script edits, create a timestamped backup when feasible.

## Change Boundaries
- Default editable targets:
  - `C:\Xerox\FFCoreForChatGPT\files`
  - `C:\Xerox\FFCoreForChatGPT\prompts`
  - `C:\Xerox\FFCoreForChatGPT\output`
  - `C:\Xerox\FFCoreForChatGPT\temp`
  - text config/script files under FreeFlow folders only when explicitly required
- Runtime data under `C:\Xerox\FreeFlow\Core\` is out-of-bounds by default for delete/move operations.

## Validation Expectations
- After changes, run the smallest safe validation available:
  - Syntax/format checks for changed text files
  - Targeted checks for key settings in modified config files
  - Log inspection for errors tied to the change
- If full validation needs service restart, installer execution, or FFCore job submission, ask first.

## Response Style
- Be concise and operational.
- Include exact file paths for every recommended change.
- Map procedural steps to relevant local documentation files.
